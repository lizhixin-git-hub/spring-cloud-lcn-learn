# transaction-dubbo 

是LCN基于dubbo的分布式事务框架