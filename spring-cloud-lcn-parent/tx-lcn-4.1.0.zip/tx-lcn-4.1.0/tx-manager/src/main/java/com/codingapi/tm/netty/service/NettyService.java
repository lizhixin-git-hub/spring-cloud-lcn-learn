package com.codingapi.tm.netty.service;

/**
 * create by lorne on 2017/11/11
 */
public interface NettyService {



    IActionService getActionService(String action);
}
